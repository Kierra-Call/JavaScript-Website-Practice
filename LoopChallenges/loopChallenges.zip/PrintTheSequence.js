for (var i = -3.5; i <= 4;i+=1.5){
    console.log(i);
}