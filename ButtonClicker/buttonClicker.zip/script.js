function logout(element) {
    element.innerText = "Logout";
}
function addDefinition(element) {
    element.remove();
}