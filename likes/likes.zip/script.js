var count1 = 9;
function likes1() {
    let countElement = document.querySelector("#like1");
    count1++;
    countElement.innerText = count1 + " like(s)"

}
var count2 = 12;
function likes2() {
    let countElement = document.querySelector("#like2");
    count2++;
    countElement.innerText = count2 + " like(s)"

}
var count3 = 9;
function likes3() {
    let countElement = document.querySelector("#like3");
    count3++;
    countElement.innerText = count3 + " like(s)"

}